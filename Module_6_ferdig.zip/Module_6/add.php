<?php

include_once "includes/db.inc.php";

if(isset($_POST["submit"])) {
        //henter ut verdiene fra form-en.
        $epost = $_POST["epost"];
        $fornavn = $_POST["fornavn"];
        $etternavn = $_POST["etternavn"];
        $adresse = $_POST["adresse"];
        $postnr = $_POST["postnr"];
        $poststed = $_POST["poststed"];
        $mobilnr = $_POST["mobilnr"];
        $fødselsdato = $_POST["fødselsdato"];
        $kjønn = $_POST["kjønn"];
        $bruker = $_POST["brukernavn"];
        $passord1 = $_POST["passord1"];
        $passord2 = $_POST["passord2"];

    echo strval($fødselsdato);
    echo $fødselsdato;
    $conn->set_charset("utf-8");

    $result = $conn->prepare("INSERT INTO medlemmer (Fornavn, Etternavn, Epost, Mobilnr, Adresse, Postnr, Poststed, Fødselsdato, Kjønn, Brukernavn, Passord) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
    
    $result->bind_param("sssisisssss", $fornavn, $etternavn, $epost, $mobilnr, $adresse, $postnr, $poststed, $fødselsdato, $kjønn, $bruker, $passord1);


    if ($result -> execute()) {
        echo "Medlemmet er registrert i databasen.";
    } else {
        echo "Noe gikk galt. Sjekk error: " . $conn->error;
    }
}
