<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modul 8</title>
</head>
<body>
    <h1>Modul 8</h1>

    <h3>Oppgave 1</h3>
    <a href="oppgave1.php">Oppgave 1-></a>

    <h3>Oppgave 2</h3>
    <a href="oppgave2.php">Oppgave 2-></a>

    <h3>Oppgave 3</h3>
    <a href="oppgave3">Oppgave 3-></a>

    <h3>Oppgave 4</h3>
    <a href="oppgave4.php">Oppgave 4-></a>

    <h3>Oppgave 5</h3>
    <a href="oppgave5.php">Oppgave 5-></a>
    
</body>
</html>