<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>IS-115</title>
</head>
<body>
    <p>Kopierte modul 7 og la til en upload funksjon</p>
    <!-- Linker til login og signup siden -->
    <h1>Modul 7</h1>
    <a href="login.php">Logg på her</a>
    <a href="signup.php">Registrer deg her</a>
</body>
</html>