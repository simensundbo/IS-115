<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modul 1</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    
    <div class="main">
    <h1>Modul 1</h1>

    <h3>Oppgave 1</h3>
    <p>Gode resurrser til php:</p>
    <ul>
        <li><a href="https://www.php.net/manual/en/">Php documentation -></a></li>
        <li><a href="https://www.w3schools.com/php/default.asp">W3 school -></a></li>
    </ul>

    <h3>Oppgave 2</h3>
    <a href="info.php">Klikk her for å se info om php -></a>

    <h3>Oppgave 3</h3>
    <a href="oppgave3.php">oppagev 3 -></a>

    <h3>Oppgave 4</h3>
    <a href="oppgave4.php">Oppgave 4 -></a>   
    
    <h3>Oppgave 5</h3>
    <a href="oppgave5.php">Oppgave 5 -></a>
 
</div>
</body>
</html>