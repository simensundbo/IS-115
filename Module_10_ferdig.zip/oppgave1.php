<?php


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Oppgave 1</title>
    <script src="js/oppgave1_script.js"></script>
</head>

<body>
    <!-- har en onclic event listner som kjører funksjonen getData() -->
    <button onclick="getData()" id="btn1">Data</button>

    <ul id="list">
        
    </ul>


    <a href="index.php">Startsiden</a>

</body>

</html>