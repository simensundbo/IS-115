<?php

$data = [
    'Simen',
    'Elias',
    'Andreas'
];



echo json_encode($data);


