<?php

?>

<!doctype html>
<html lang="EN">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="js/oppgave2_script.js"></script>
</head>

<body id="body">
    <p id="myTag">Bytter farge</p>

    <a href="index.php">Startsiden</a>

</body>

</html>