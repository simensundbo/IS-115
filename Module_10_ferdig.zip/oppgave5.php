<?php

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Oppgave 5</title>
</head>

<!-- når siden lastes inn kjører getTemp funksjonen -->
<body onload="getTemp()">
    <p>Oppgave 5</p>

    <div >
        <p id="place"></p>
        <p id="temp"></p>
    </div>

    <a href="index.php">Startsiden</a>

    <script src="js/oppgave5_script.js"></script>
</body>

</html>